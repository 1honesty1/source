﻿namespace AuthSystem.Models
{
    public static class UserRoles
    {
        public const string Admin = "Admin";
        public const string Dispetcer = "Dispetcer";
        public const string Worker = "Worker";
    }
}
