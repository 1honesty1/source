﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthSystem.Controllers
{
    [Authorize(Roles = "Dispetcer")]
    public class DispetcerController : Controller
    {
        public IActionResult AdditionalAction()
        {
            return View();
        }

        public IActionResult AddTask()
        {
            return View();
        }
    }
}
