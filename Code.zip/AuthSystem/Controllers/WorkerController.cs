﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthSystem.Controllers
{
    [Authorize(Roles = "Worker")]
    public class WorkerController : Controller
    {
        public IActionResult ViewTasks()
        {
            return View();
        }
    }
}
